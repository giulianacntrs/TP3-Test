import { Router } from "express";
import { guardarRespuestas } from "../controllers/respuestas.controller.js";

const router = Router();

router.post("/", guardarRespuestas);

export default router;
