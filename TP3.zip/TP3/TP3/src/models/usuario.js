import { query } from "../mysql"; 
/**
 * @param {string} nombre
 * @param {string} email
 * @param {string} contrasena (¡Debe ser el hash de bcrypt!)
 * @param {string} genero
 * @param {number} edad
 * @param {string} modalidad_trabajo
 * @returns {object} Resultado de la inserción (incluye insertId).
 */
const usuario = async (nombre, email, contrasena, genero, edad, modalidad_trabajo) => {
    const sql = `
        INSERT INTO usuarios 
        (nombre, email, contrasena, genero, edad, modalidad_trabajo) 
        VALUES (?, ?, ?, ?, ?, ?)
    `;
    
    try {
        const [resultado] = await query(sql, [nombre, email, contrasena, genero, edad, modalidad_trabajo]);
        return resultado;
    } catch (error) {
        throw error;
    }
};

/**
 * @param {string} email
 * @returns {object | undefined} 
 */
const findByEmail = async (email) => {
    const sql = `
        SELECT id, nombre, email, contrasena, genero, edad, modalidad_trabajo 
        FROM usuarios 
        WHERE email = ?
    `;
    
    try {
        const [rows] = await query(sql, [email]);
        return rows[0]; 
    } catch (error) {
        throw error;
    }
};


/**
 * @returns {array} 
 */
const findAll = async () =>{
    const sql = "SELECT id, nombre, email, genero, edad, modalidad_trabajo FROM usuarios";

    try {
        const [rows] = await query(sql);
        return rows;
    } catch (error) {
        throw error;
    }
}

export default {
    usuario,       
    findByEmail,  
    findAll       
};