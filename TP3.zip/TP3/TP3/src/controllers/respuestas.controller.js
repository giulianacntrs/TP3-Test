import { db } from "../db/connection.js";

export const guardarRespuestas = async (req, res) => {
  const { id_usuario, respuestas } = req.body;
  // respuestas = [{id_pregunta: 1, valor: "8"}, ...]

  const insertValues = respuestas.map(r => [id_usuario, r.id_pregunta, r.valor]);

  await db.query(
    "INSERT INTO respuestas (id_usuario, id_pregunta, valor) VALUES ?",
    [insertValues]
  );

  res.json({ message: "Respuestas guardadas correctamente" });
};
