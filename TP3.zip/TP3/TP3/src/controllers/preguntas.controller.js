import { db } from "../db/connection.js";

export const obtenerPreguntasTest = async (req, res) => {
  const [rows] = await db.query("SELECT * FROM preguntas ORDER BY id_pregunta");
  res.json(rows);
};
