const bcrypt = require('bcrypt');
const model = require('../models/Usuario').default;
const jwt = require('jsonwebtoken'); 

const JWT_SECRET = process.env.JWT_SECRET; 

const registrarUsuario = async (req, res) => {
    const { nombre, email, contrasena, genero, edad, modalidad_trabajo } = req.body;

    if (!nombre || !email || !contrasena || !genero || !edad || !modalidad_trabajo) {
        return res.status(400).json({ message: "Faltan campos obligatorios para el registro." });
    }

    try {
        const contrasenaHasheada = await bcrypt.hash(contrasena, SALT_ROUNDS);

        const resultado = await model.usuario(
            nombre,
            email,
            contrasenaHasheada,
            genero,
            edad,
            modalidad_trabajo
        );

        res.status(201).json({ 
            message: "Usuario registrado con éxito.", 
            userId: resultado.insertId 
        });

    } catch (error) {
        console.error("Error en registro:", error);
        
        if (error.code === 'ER_DUP_ENTRY') { 
            return res.status(409).json({ message: "El correo electrónico ya está en uso." });
        }
        
        res.status(500).json({ message: "Error interno del servidor al intentar registrar." });
    }
};
const loginUsuario = async (req, res) => {
    const { email, contrasena } = req.body;

    if (!email || !contrasena) {
        return res.status(400).json({ message: "Email y contraseña son requeridos." });
    }

    try {
        // 1. Buscar el usuario por email usando el modelo
        const usuario = await model.findByEmail(email);

        // 2. Verificar si el usuario existe
        if (!usuario) {
            // Error 401: No autorizado (credenciales inválidas)
            return res.status(401).json({ message: "Credenciales inválidas." });
        }

        // 3. Comparar la contraseña ingresada con el hash de la BD
        const esValido = await bcrypt.compare(contrasena, usuario.contrasena);

        if (!esValido) {
            return res.status(401).json({ message: "Credenciales inválidas." });
        }

        // 4. Generación del Token JWT
        const token = jwt.sign(
            // Payload: información del usuario a guardar en el token
            { id: usuario.id, email: usuario.email, nombre: usuario.nombre }, 
            JWT_SECRET, 
            { expiresIn: '24h' }
        );

        // Respuesta de éxito con el token
        return res.status(200).json({ 
            message: "Login exitoso", 
            token: token 
        });

    } catch (error) {
        console.error("Error en login:", error);
        res.status(500).json({ message: "Error interno del servidor." });
    }
};

module.exports = {
    registrarUsuario,
    loginUsuario
};