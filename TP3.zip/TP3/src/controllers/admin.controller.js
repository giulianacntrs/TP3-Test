import { db } from "../models/mysql.js";

export const obtenerPreguntas = async (req, res) => {
  const [rows] = await db.query("SELECT * FROM preguntas");
  res.json(rows);
};

export const crearPregunta = async (req, res) => {
  const { texto_pregunta, tipo } = req.body;

  await db.query(
    "INSERT INTO preguntas (texto_pregunta, tipo) VALUES (?, ?)",
    [texto_pregunta, tipo]
  );

  res.json({ message: "Pregunta creada" });
};

export const actualizarPregunta = async (req, res) => {
  const { id } = req.params;
  const { texto_pregunta, tipo } = req.body;

  await db.query(
    "UPDATE preguntas SET texto_pregunta = ?, tipo = ? WHERE id_pregunta = ?",
    [texto_pregunta, tipo, id]
  );

  res.json({ message: "Pregunta actualizada" });
};

export const eliminarPregunta = async (req, res) => {
  const { id } = req.params;

  await db.query("DELETE FROM preguntas WHERE id_pregunta = ?", [id]);

  res.json({ message: "Pregunta eliminada" });
};
