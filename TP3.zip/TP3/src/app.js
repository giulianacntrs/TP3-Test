import express from "express";
import adminRoutes from "./routes/admin.routes.js";
import preguntasRoutes from "./routes/preguntas.routes.js";
import respuestasRoutes from "./routes/respuestas.routes.js";
import dashboardRoutes from "./routes/dashboard.routes.js";

const app = express();

app.use(express.json());

app.use("/admin", adminRoutes);
app.use("/preguntas", preguntasRoutes);
app.use("/respuestas", respuestasRoutes);
app.use("/dashboard", dashboardRoutes);

app.listen(3000, () => console.log("Servidor iniciado en puerto 3000"));
