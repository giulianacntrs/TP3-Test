import { Router } from "express";
import {
  crearPregunta,
  obtenerPreguntas,
  actualizarPregunta,
  eliminarPregunta
} from "../controllers/admin.controller.js";

const router = Router();

router.get("/preguntas", obtenerPreguntas);
router.post("/preguntas", crearPregunta);
router.put("/preguntas/:id", actualizarPregunta);
router.delete("/preguntas/:id", eliminarPregunta);

export default router;
