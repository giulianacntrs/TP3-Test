import { Router } from "express";
import { obtenerPreguntasTest } from "../controllers/preguntas.controller.js";

const router = Router();

router.get("/", obtenerPreguntasTest);

export default router;
